#ifndef PRIORITY_H_
#define PRIOTITY_H_

int compute_priority(int base) {
	return 100 - base;
}

#endif