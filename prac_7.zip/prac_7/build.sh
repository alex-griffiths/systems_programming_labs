cc src/main.c -o build/main
cc src/signal.c -o build/signal